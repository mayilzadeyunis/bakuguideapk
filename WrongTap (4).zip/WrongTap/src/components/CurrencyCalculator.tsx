import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Currency, ArrowRight } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const CurrencyCalculator = () => {
  const [amount, setAmount] = useState<string>('');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('AZN');

  const rates = {
    USD: { AZN: 1.7, EUR: 0.92, GBP: 0.79, TRY: 28.5, RUB: 89.5, CNY: 7.2 },
    AZN: { USD: 0.59, EUR: 0.54, GBP: 0.46, TRY: 16.8, RUB: 52.6, CNY: 4.2 },
    EUR: { USD: 1.09, AZN: 1.85, GBP: 0.86, TRY: 31.0, RUB: 97.4, CNY: 7.8 },
    GBP: { USD: 1.27, AZN: 2.15, EUR: 1.16, TRY: 36.0, RUB: 113.2, CNY: 9.1 },
    TRY: { USD: 0.035, AZN: 0.060, EUR: 0.032, GBP: 0.028, RUB: 3.14, CNY: 0.25 },
    RUB: { USD: 0.011, AZN: 0.019, EUR: 0.010, GBP: 0.009, TRY: 0.32, CNY: 0.080 },
    CNY: { USD: 0.14, AZN: 0.24, EUR: 0.13, GBP: 0.11, TRY: 4.0, RUB: 12.5, }
  };

  const calculateAmount = (): string => {
    const value = parseFloat(amount);
    if (isNaN(value)) return '0.00';
    if (fromCurrency === toCurrency) return value.toFixed(2);
    return (value * rates[fromCurrency][toCurrency]).toFixed(2);
  };

  return (
    <Card className="p-6 bg-gradient-to-br from-baku-primary/10 to-baku-secondary/10 backdrop-blur-sm">
      <div className="flex items-center mb-4">
        <Currency size={24} className="text-baku-primary mr-2" />
        <h2 className="text-xl font-bold text-baku-primary">Currency Converter</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[2fr,1fr,2fr] gap-4 items-center">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-600">Amount</label>
          <Input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="Enter amount"
            className="bg-white/50 border-baku-primary/20"
          />
        </div>

        <div className="flex items-center justify-center">
          <ArrowRight className="text-baku-primary" size={24} />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-600">Result</label>
          <div className="text-2xl font-bold text-baku-primary">
            {calculateAmount()} {toCurrency}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-600">From</label>
          <Select value={fromCurrency} onValueChange={setFromCurrency}>
            <SelectTrigger className="bg-white/50">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USD">USD - US Dollar</SelectItem>
              <SelectItem value="EUR">EUR - Euro</SelectItem>
              <SelectItem value="GBP">GBP - British Pound</SelectItem>
              <SelectItem value="AZN">AZN - Azerbaijani Manat</SelectItem>
              <SelectItem value="TRY">TRY - Turkish Lira</SelectItem>
              <SelectItem value="RUB">RUB - Russian Ruble</SelectItem>
              <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="md:col-start-3 space-y-2">
          <label className="text-sm font-medium text-gray-600">To</label>
          <Select value={toCurrency} onValueChange={setToCurrency}>
            <SelectTrigger className="bg-white/50">
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="AZN">AZN - Azerbaijani Manat</SelectItem>
              <SelectItem value="USD">USD - US Dollar</SelectItem>
              <SelectItem value="EUR">EUR - Euro</SelectItem>
              <SelectItem value="GBP">GBP - British Pound</SelectItem>
              <SelectItem value="TRY">TRY - Turkish Lira</SelectItem>
              <SelectItem value="RUB">RUB - Russian Ruble</SelectItem>
              <SelectItem value="CNY">CNY - Chinese Yuan</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </Card>
  );
};

export default CurrencyCalculator;