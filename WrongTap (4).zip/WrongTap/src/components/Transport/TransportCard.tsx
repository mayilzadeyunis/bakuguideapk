import React from 'react';
import { cn } from '@/lib/utils';

interface TransportCardProps extends React.HTMLAttributes<HTMLDivElement> {
  type: "bus" | "metro";
  number: string;
  name?: string;
  startPoint?: string;
  endPoint?: string;
  frequency?: string;
  active?: boolean;
  isAeroexpress?: boolean;
  image?: string;
  description?: string;
}

const TransportCard: React.FC<TransportCardProps> = ({ 
  type, 
  number,
  name,
  startPoint,
  endPoint,
  frequency,
  active = false,
  isAeroexpress = false,
  image,
  description,
  className, 
  ...props 
}) => {
  return (
    <div 
      className={cn(
        "baku-card p-4 hover:shadow-md transition-all duration-200 cursor-pointer",
        active 
          ? type === "bus" 
            ? "border-2 border-baku-secondary bg-gradient-to-r from-blue-50 to-sky-50" 
            : "border-2 border-baku-ruby bg-gradient-to-r from-rose-50 to-pink-50"
          : "",
        isAeroexpress ? "bg-gradient-to-r from-sky-50 to-blue-50" : "",
        className
      )}
      {...props}
    >
      <div className={cn("flex", isAeroexpress ? "flex-col" : "items-center")}>
        {isAeroexpress && image && (
          <img src={image} alt={name} className="w-full h-40 object-cover rounded-lg mb-4 shadow-sm" />
        )}
        <div className="flex items-center w-full">
          <div className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center text-white font-bold mr-3 shadow-sm",
            isAeroexpress 
              ? "bg-sky-500" 
              : type === "bus" 
                ? "bg-baku-secondary bg-gradient-to-br from-blue-500 to-blue-600" 
                : "bg-baku-ruby bg-gradient-to-br from-rose-500 to-rose-600"
          )}>
            {number}
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-gray-800">{name || `${type.toUpperCase()} ${number}`}</h3>
            {(startPoint && endPoint) && (
              <div className="flex items-center text-sm text-gray-600 mt-1">
                <span className="font-medium">{startPoint}</span>
                <span className="mx-1 text-gray-400">→</span>
                <span className="font-medium">{endPoint}</span>
              </div>
            )}
            {frequency && (
              <div className="flex items-center text-xs text-gray-500 mt-1">
                <span className="inline-block w-2 h-2 rounded-full bg-green-400 mr-1"></span>
                Every {frequency}
              </div>
            )}
          </div>
        </div>
        {isAeroexpress && description && (
          <p className="text-sm text-gray-600 mt-3 border-t pt-3 leading-relaxed">{description}</p>
        )}
      </div>
    </div>
  );
};

export default TransportCard;