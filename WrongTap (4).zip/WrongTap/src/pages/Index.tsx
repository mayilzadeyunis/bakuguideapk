import React from 'react';
import CurrencyCalculator from '@/components/CurrencyCalculator';
import BottomNav from '@/components/Navigation/BottomNav';
import Hero from '@/components/Hero';
import FeatureCard from '@/components/FeatureCard';
import { Map, Landmark, Building, Sun, Currency, BookOpen, BrainCircuit } from 'lucide-react';
import { Link } from 'react-router-dom';
import LiveDateTime from '@/components/LiveDateTime';

const Index = () => {
  return (
    <div className="pb-16">
      <Hero 
        title="Discover Baku"
        subtitle="Your comprehensive guide to Azerbaijan's capital"
        image="/attached_assets/_D859762-1-1667589414-1667589414.jpg"
        height="lg"
      />
      
      <section className="p-4">
        <h2 className="text-xl font-bold mb-4 text-baku-dark">Explore Baku</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FeatureCard 
            title="Public Transport"
            description="Navigate Baku with bus & metro routes"
            icon={<Map size={24} color="white" />}
            to="/transport"
            color="primary"
          />
          
          <FeatureCard 
            title="Places to Visit"
            description="Discover historical sites & hidden gems"
            icon={<Landmark size={24} color="white" />}
            to="/places"
            color="secondary"
          />
          
          <FeatureCard 
            title="Local Services"
            description="Emergency contacts & tourist information"
            icon={<Building size={24} color="white" />}
            to="/services"
            color="accent"
          />
          
          <FeatureCard 
            title="About Baku"
            description="Learn about the history & culture of Baku"
            icon={<Landmark size={24} color="white" />}
            to="/about"
            color="primary"
          />
        </div>
      </section>

      <section className="p-4 mt-4">
        <Link to="/quiz" className="block">
          <div className="relative overflow-hidden rounded-xl shadow-lg bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="absolute top-0 left-0 w-full h-full bg-black opacity-20"></div>
            <div className="relative z-10 p-6 text-white">
              <div className="flex items-center mb-4">
                <div className="bg-white/20 p-3 rounded-full">
                  <BrainCircuit size={32} className="text-white" />
                </div>
                <div className="ml-4">
                  <h3 className="text-2xl font-bold">Test Your Knowledge!</h3>
                  <p className="text-white/80">Take our Baku quiz and discover interesting facts</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-4">
                <div className="flex space-x-2">
                  <span className="bg-white/20 text-xs font-semibold px-2.5 py-1 rounded-full">10 Questions</span>
                  <span className="bg-white/20 text-xs font-semibold px-2.5 py-1 rounded-full">Fun Facts</span>
                  <span className="bg-white/20 text-xs font-semibold px-2.5 py-1 rounded-full">History & Culture</span>
                </div>
                <div className="bg-white/30 hover:bg-white/40 transition-colors rounded-full p-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
              
              <div className="mt-6 flex items-center space-x-3">
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full bg-blue-400 flex items-center justify-center text-xs font-bold">A</div>
                  <div className="w-8 h-8 rounded-full bg-green-400 flex items-center justify-center text-xs font-bold">B</div>
                  <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center text-xs font-bold">C</div>
                  <div className="w-8 h-8 rounded-full bg-red-400 flex items-center justify-center text-xs font-bold">D</div>
                </div>
                <p className="text-sm">Challenge yourself with our interactive quiz!</p>
              </div>
            </div>
          </div>
        </Link>
      </section>

      <section className="p-4 mt-4">
        <h2 className="text-xl font-bold mb-4 text-baku-dark">Did You Know?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-baku-primary to-baku-secondary p-6 rounded-xl text-white shadow-lg transform hover:scale-105 transition-transform">
            <h3 className="text-lg font-bold mb-2">Ancient History</h3>
            <p>Baku has been inhabited since the Stone Age and was mentioned in ancient Roman texts as early as the 1st century AD.</p>
          </div>
          <div className="bg-gradient-to-br from-baku-secondary to-baku-accent p-6 rounded-xl text-white shadow-lg transform hover:scale-105 transition-transform">
            <h3 className="text-lg font-bold mb-2">UNESCO Heritage</h3>
            <p>The walled Inner City (Icheri Sheher) of Baku is a UNESCO World Heritage site, featuring the iconic Maiden Tower.</p>
          </div>
          <div className="bg-gradient-to-br from-baku-accent to-baku-ruby p-6 rounded-xl text-white shadow-lg transform hover:scale-105 transition-transform">
            <h3 className="text-lg font-bold mb-2">Natural Phenomenon</h3>
            <p>Baku is home to unique mud volcanoes, with Azerbaijan having nearly 400 of the world's 800 known mud volcanoes.</p>
          </div>
          <div className="bg-gradient-to-br from-baku-ruby to-baku-primary p-6 rounded-xl text-white shadow-lg transform hover:scale-105 transition-transform">
            <h3 className="text-lg font-bold mb-2">Modern Marvel</h3>
            <p>The Flame Towers, completed in 2012, are one of the tallest buildings in Azerbaijan and feature LED displays visible from most of the city.</p>
          </div>
        </div>
      </section>

      <section className="p-4 mt-4">
        <div className="bg-baku-primary/10 p-4 rounded-xl">
          <h2 className="text-xl font-bold mb-2 text-baku-primary">Baku Travel Tips</h2>
          <ul className="space-y-2">
            <li className="flex items-start">
              <span className="bg-baku-primary text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 mt-1">1</span>
              <div>
                <p className="font-medium">BakuCard for transport</p>
                <p className="text-sm text-gray-600">Purchase a BakuCard for easier metro and bus travel</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="bg-baku-primary text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 mt-1">2</span>
              <div>
                <p className="font-medium">Download offline maps</p>
                <p className="text-sm text-gray-600">Save maps for offline use when exploring the city</p>
              </div>
            </li>
            <li className="flex items-start">
              <span className="bg-baku-primary text-white w-6 h-6 rounded-full flex items-center justify-center mr-2 mt-1">3</span>
              <div>
                <p className="font-medium">Currency exchange</p>
                <p className="text-sm text-gray-600">Exchange money at official banks for better rates</p>
              </div>
            </li>
          </ul>
        </div>
      </section>

      <section className="p-4 mt-4 mb-20">
        <h2 className="text-xl font-bold mb-4 text-baku-dark">Currency Exchange</h2>
        <CurrencyCalculator />
      </section>

      <BottomNav activeTab="home" />
    </div>
  );
};

export default Index;