import React, { useState } from 'react';
import Header from '@/components/Header';
import BottomNav from '@/components/Navigation/BottomNav';
import PlaceCard from '@/components/Places/PlaceCard';
import ParkCard from '@/components/Places/ParkCard';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Places = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const places = [
    {
      name: "Mini Venice",
      location: "Baku Boulevard",
      image: "/attached_assets/2pRIFcz0Nku6q4rwXm91GZFf6j1UZYRBNWcb6INe.jpg",
      category: "Attraction",
      hours: "11:00 AM - 9:00 PM",
      description: "Experience the charm of Venice with beautiful canals and gondola rides",
      featured: true,
    },
    {
      name: "Baku Eye",
      location: "Seaside Boulevard",
      image: "/attached_assets/47.jpg",
      category: "Landmark",
      hours: "12:00 PM - 8:00 PM",
      description: "Adults: 10 AZN, Children: 5 AZN",
      featured: true,
    },
    {
      name: "Fountain Square",
      location: "Downtown Baku",
      image: "/attached_assets/fonttttt.jpg",
      category: "Landmark",
      hours: "Open 24/7",
      featured: true,
    },
    {
      name: "Heydar Aliyev Center",
      location: "1 Heydar Aliyev Avenue",
      image: "/attached_assets/unnamed.webp",
      category: "Cultural",
      hours: "10:30 AM - 6:00 PM",
      featured: true,
    },
    {
      name: "Maiden Tower",
      location: "Icherisheher",
      image: "/attached_assets/b8c99d401b90bd06021c122b4346c8f7-maiden-s-tower.jpg",
      category: "Historical",
      hours: "10:00 AM - 7:00 PM",
      featured: true,
    },
    {
      name: "Flame Towers",
      location: "Istiglaliyyat Street", 
      image: "/attached_assets/1687420482.jpg",
      category: "Landmark",
      hours: "9:00 AM - 6:00 PM",
      featured: true,
    },
    {
      name: "Azerbaijan National Museum of Art",
      location: "9/11 Niyazi, Bakı",
      image: "/attached_assets/IMG_2910.jpg",
      category: "Museum",
      hours: "10:00 AM - 8:00 PM",
      featured: false,
      },
    {
      name: "Azerbaijan National Museum of History",
      location: "Downtown Baku",
      image: "/attached_assets/nationalmuseum.jpg",
      category: "Museum",
      hours: "10:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Baku Boulevard",
      location: "Baku Boulevard",
      image: "/attached_assets/c2.jpg",
      category: "Park",
      hours: "Open 24/7",
      featured: false,
    },
    {
      name: "Old City (Icherisheher)",
      location: "Central Baku",
      image: "/attached_assets/media-Iceriseher-0ukgc9.jpg",
      category: "Historical",
      hours: "Open 24/7",
      featured: true,
    },
    {
      name: "Nizami Street",
      location: "Downtown Baku",
      image: "/attached_assets/nizami-street-of-baku.webp",
      category: "Cultural",
      hours: "Open 24/7",
      featured: false,
    },
    {
      name: "Azerbaijan Carpet Museum",
      location: "Baku Boulevard",
      image: "/attached_assets/remote.jpg.jpeg",
      category: "Museum",
      hours: "10:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Museum of Miniature Books",
      location: "Old City",
      image: "/attached_assets/19.jpg",
      category: "Museum",
      hours: "11:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Surakhani Ship Museum",
      location: "Surakhani district",
      image: "/attached_assets/surakhani.jpg",
      category: "Museum",
      hours: "10:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Nizami Museum of Literature",
      location: "Istiglaliyyat Street",
      image: "/attached_assets/Nizami_museum.jpg",
      category: "Museum",
      hours: "11:00 AM - 5:00 PM",
      featured: false,
    },
    {
      name: "Museum of Modern Art",
      location: "Yusuph Safarov Street",
      image: "/attached_assets/mim-modern-art-museum.jpg",
      category: "Museum",
      hours: "11:00 AM - 8:00 PM",
      featured: false,
    },
    {
      name: "Palace of the Shirvanshahs",
      location: "Old City",
      image: "/attached_assets/shirvan5.jpeg",
      category: "Historical",
      hours: "10:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Ateshgah Fire Temple",
      location: "Surakhani Settlement",
      image: "/attached_assets/azerbaycan-ateşgah.png",
      category: "Historical",
      hours: "10:00 AM - 6:00 PM",
      featured: false,
    },
    {
      name: "Bibi Heybet Mosque",
      location: "Bibi Heybat",
      image: "/attached_assets/Bibi_Heybat_Mosque_Baku_1.jpg",
      category: "Historical",
      hours: "Open for prayers",
      featured: false,
    },
  ];

  const parks = [
    {
      name: "Genclik Park",
      location: "Genclik park",
      image: "/attached_assets/genclik.jpg",
      description: "A vibrant recreational park featuring a variety of attractions including walking paths, sports facilities, and entertainment areas. Popular among both locals and tourists for its well-maintained grounds and family-friendly atmosphere.",
      hours: "Open 24/7",
      facilities: ["Walking Paths", "Sports Facilities", "Children's Playground", "Entertainment Areas", "Food Court"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3897,
        lng: 49.8290
      }
    },
    {
      name: "Chemberekend Park",
      location: "Chemberekend district",
      image: "/attached_assets/parkkkk.jpg",
      description: "A peaceful neighborhood park with well-maintained walking paths and recreational areas. Perfect for local residents and visitors looking for a quiet spot to relax.",
      hours: "Open 24/7",
      facilities: ["Walking Paths", "Benches", "Children's Playground", "Green Areas"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3752,
        lng: 49.8450
      }
    },
    {
      name: "Boyuk Shor Park",
      location: "Boyuk Shor Lake area",
      image: "/attached_assets/parkkk.jpg",
      description: "A modern recreational area near Boyuk Shor Lake featuring sports facilities and walking trails. The park offers a mix of outdoor activities and relaxation spaces.",
      hours: "Open 24/7",
      facilities: ["Sports Facilities", "Walking Trails", "Seating Areas", "Viewpoints"],
      entryFee: "Free",
      coordinates: {
        lat: 40.4225,
        lng: 49.8673
      }
    },
    {
      name: "Central Park",
      location: "City Center",
      image: "/attached_assets/parkk.jpg",
      description: "Located in the heart of Baku, Central Park offers a green oasis with beautiful landscaping, recreational facilities, and various entertainment options for visitors of all ages.",
      hours: "Open 24/7",
      facilities: ["Fountains", "Children's Areas", "Walking Paths", "Rest Areas", "Cafes"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3789,
        lng: 49.8536
      }
    },
    {
      name: "Baku Zoo",
      location: "Bakikhanov Street",
      image: "/attached_assets/Baku_Zoo.jpg",
      description: "Baku Zoo is Azerbaijan's largest zoo, home to over 160 species of animals. The zoo features both local and exotic animals, educational programs, and is a popular destination for families. Recently renovated, it provides modern facilities and spacious enclosures for its inhabitants.",
      hours: "10:00 AM - 5:30 PM",
      facilities: ["Animal Exhibits", "Food Court", "Gift Shop", "Information Center", "Rest Areas"],
      entryFee: "7 AZN",
      coordinates: {
        lat: 40.3895,
        lng: 49.8548
      }
    },
    {
      name: "Baku Boulevard",
      location: "Baku Boulevard",
      image: "/attached_assets/boulevard.jpg",
      description: "The Baku Boulevard is a promenade that runs parallel to Baku's seafront. The park is 3.75 km long and was established in 1909. It's a popular place for locals and tourists to walk, enjoy the view of the Caspian Sea, and visit nearby attractions.",
      hours: "Open 24/7",
      facilities: ["Cafes", "Benches", "Bike Rentals", "Children's Play Areas", "Fountains"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3711,
        lng: 49.8372
      }
    },
    {
      name: "Zabitler Park",
      location: "Baku City Center",
      image: "/attached_assets/caption.jpg",
      description: "Zabitler Park, also known as Officers Park, is a beautiful green space in downtown Baku. It features well-maintained gardens, fountains, and is surrounded by historical buildings. The park is an ideal spot for a leisurely stroll or a quick break from city exploration.",
      hours: "Open 24/7",
      facilities: ["Benches", "Fountains", "Walking Paths", "Historical Monuments"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3774,
        lng: 49.8521
      }
    },
    {
      name: "Heydar Aliyev Park",
      location: "Nasimi district",
      image: "/attached_assets/heydar-aliyev-park.jpg",
      description: "Named after Azerbaijan's former president, this large park features beautifully landscaped gardens, fountains, and a monument to Heydar Aliyev. It's a popular spot for family gatherings and community events.",
      hours: "Open 24/7",
      facilities: ["Children's Playground", "Fountains", "Walking Paths", "Monuments", "Seating Areas"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3943,
        lng: 49.8284
      }
    },
    {
      name: "Dagustu (Highland) Park",
      location: "Uphill from Parliament Avenue",
      image: "/attached_assets/highland-park-baku-tour-azerbaijan.jpg",
      description: "Located on a hill overlooking the city, Highland Park offers one of the best panoramic views of Baku. The park features the Alley of Martyrs, a memorial dedicated to those killed during the Black January events and the Nagorno-Karabakh War.",
      hours: "Open 24/7",
      facilities: ["Viewpoints", "Memorials", "Walking Paths", "Benches"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3612,
        lng: 49.8325
      }
    },

    {
      name: "Central Botanical Garden",
      location: "Patamdart Highway",
      image: "/attached_assets/Botanical_4-scaled.jpg",
      description: "Spanning over 16 hectares, this botanical garden is home to more than 2,500 species of trees and plants from around the world. It's a peaceful retreat from the city's hustle and bustle, perfect for nature lovers and those interested in botany.",
      hours: "9:00 AM - 5:00 PM",
      facilities: ["Greenhouse", "Research Center", "Walking Paths", "Rare Plant Collections", "Picnic Areas"],
      entryFee: "2 AZN",
      coordinates: {
        lat: 40.3483,
        lng: 49.8281
      }
    },

    {
      name: "Khagani Garden",
      location: "City Center, near Fountains Square",
      image: "/attached_assets/325693.jpg",
      description: "A small but charming garden in the heart of the city, named after the 12th-century Azerbaijani poet Khagani Shirvani. It features a statue of the poet and is surrounded by historic buildings. The garden is a popular meeting spot for locals.",
      hours: "Open 24/7",
      facilities: ["Benches", "Historical Monument", "Shade Trees"],
      entryFee: "Free",
      coordinates: {
        lat: 40.3719,
        lng: 49.8371
      }
    }
  ];

  const filteredPlaces = searchQuery 
    ? places.filter(place => 
        place.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        place.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        place.location.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : places;

  const filteredParks = searchQuery 
    ? parks.filter(park => 
        park.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        park.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        park.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : parks;

  return (
    <div className="pb-16">
      <Header title="Places to Visit" subtitle="Discover Baku's attractions" />

      <div className="p-4">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input
            placeholder="Search places..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="historical">Historical</TabsTrigger>
            <TabsTrigger value="cultural">Cultural</TabsTrigger>
            <TabsTrigger value="parks">Parks</TabsTrigger>
            <TabsTrigger value="museums">Museums</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredPlaces.map((place, index) => (
                <PlaceCard
                  key={index}
                  name={place.name}
                  location={place.location}
                  image={place.image}
                  category={place.category}
                  hours={place.hours}
                  featured={place.featured}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="historical" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredPlaces
                .filter(place => place.category === "Historical")
                .map((place, index) => (
                  <PlaceCard
                    key={index}
                    name={place.name}
                    location={place.location}
                    image={place.image}
                    category={place.category}
                    hours={place.hours}
                    featured={place.featured}
                  />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="cultural" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredPlaces
                .filter(place => place.category === "Cultural")
                .map((place, index) => (
                  <PlaceCard
                    key={index}
                    name={place.name}
                    location={place.location}
                    image={place.image}
                    category={place.category}
                    hours={place.hours}
                    featured={place.featured}
                  />
                ))}
            </div>
          </TabsContent>

          <TabsContent value="parks" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredParks.map((park, index) => (
                <ParkCard
                  key={index}
                  name={park.name}
                  location={park.location}
                  image={park.image}
                  description={park.description}
                  hours={park.hours}
                  facilities={park.facilities}
                  entryFee={park.entryFee}
                  coordinates={park.coordinates}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="museums" className="mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredPlaces
                .filter(place => place.category === "Museum")
                .map((place, index) => (
                  <PlaceCard
                    key={index}
                    name={place.name}
                    location={place.location}
                    image={place.image}
                    category={place.category}
                    hours={place.hours}
                    featured={place.featured}
                  />
                ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNav activeTab="places" />
    </div>
  );
};

export default Places;