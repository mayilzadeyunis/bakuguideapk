import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/Navigation/BottomNav';

// Quiz data with questions, options, and correct answers
const quizData = [
  {
    question: "What year did Baku become the capital of Azerbaijan?",
    options: [
      "1918", 
      "1920", 
      "1936", 
      "1991"
    ],
    correctAnswer: "1920",
    explanation: "Baku became the capital of the Azerbaijan Soviet Socialist Republic in 1920 and remained the capital when Azerbaijan gained independence in 1991."
  },
  {
    question: "Which UNESCO World Heritage site is located in Baku?",
    options: [
      "Flame Towers", 
      "Heydar Aliyev Center", 
      "Walled City of Baku with the Shirvanshah's Palace and Maiden Tower", 
      "Baku Boulevard"
    ],
    correctAnswer: "Walled City of Baku with the Shirvanshah's Palace and Maiden Tower",
    explanation: "The Walled City of Baku, including the Shirvanshah's Palace and Maiden Tower, was designated as a UNESCO World Heritage site in 2000."
  },
  {
    question: "What is the national currency of Azerbaijan?",
    options: [
      "Lira", 
      "Ruble", 
      "Dinar", 
      "Manat"
    ],
    correctAnswer: "Manat",
    explanation: "The Azerbaijani Manat (AZN) is the official currency of Azerbaijan."
  },
  {
    question: "Which architectural masterpiece designed by Zaha Hadid is located in Baku?",
    options: [
      "Flame Towers", 
      "Heydar Aliyev Center", 
      "Azerbaijan National Carpet Museum", 
      "Baku Crystal Hall"
    ],
    correctAnswer: "Heydar Aliyev Center",
    explanation: "The Heydar Aliyev Center, known for its distinctive flowing curves and lack of sharp angles, was designed by renowned architect Zaha Hadid."
  },
  {
    question: "What is the meaning of 'Baku' according to one popular etymology?",
    options: [
      "Land of Fire", 
      "City of Winds", 
      "Golden Shore", 
      "Eastern Pearl"
    ],
    correctAnswer: "City of Winds",
    explanation: "One of the most accepted etymologies suggests that 'Baku' derives from the Persian 'Bād-kube' meaning 'Wind-pounded city' or 'City of winds'."
  },
  {
    question: "Which of these natural phenomena is Azerbaijan known for and has led to it being called 'The Land of Fire'?",
    options: [
      "Frequent forest fires", 
      "Volcanic activity", 
      "Natural gas fires", 
      "Hot springs"
    ],
    correctAnswer: "Natural gas fires",
    explanation: "Azerbaijan is known for its natural gas fires that burn continuously, most famously at Yanar Dag (Burning Mountain) and the Ateshgah Fire Temple."
  },
  {
    question: "What traditional Azerbaijani musical instrument has been recognized by UNESCO as Intangible Cultural Heritage?",
    options: [
      "Tar", 
      "Kamancha", 
      "Balaban", 
      "Garmon"
    ],
    correctAnswer: "Tar",
    explanation: "The tar, a long-necked string instrument, was added to UNESCO's Representative List of the Intangible Cultural Heritage of Humanity in 2012."
  },
  {
    question: "Which Azerbaijani carpet-weaving style is named after the Baku region?",
    options: [
      "Guba", 
      "Shirvan", 
      "Absheron", 
      "Karabakh"
    ],
    correctAnswer: "Absheron",
    explanation: "The Absheron carpet-weaving style, named after the peninsula where Baku is located, is known for its distinctive patterns and composition."
  },
  {
    question: "What is the name of the tower in Baku that is surrounded by legends and located in the Old City?",
    options: [
      "Maiden Tower", 
      "Clock Tower", 
      "Victory Tower", 
      "Freedom Tower"
    ],
    correctAnswer: "Maiden Tower",
    explanation: "The Maiden Tower (Qız Qalası) is one of Baku’s most famous landmarks, located in the heart of the Old City (Icherisheher)."
  },
  {
    question: "Which seaside boulevard in Baku is popular for walking, entertainment, and views of the Caspian Sea?",
    options: [
      "Nizami Street", 
      "Torgovaya Lane", 
      "Baku Boulevard", 
      "Azadliq Avenue"
    ],
    correctAnswer: "Baku Boulevard",
    explanation: "Baku Boulevard (also known as the Seaside National Park) is a long promenade along the Caspian Sea. It’s one of the most beloved places in Baku for locals and tourists alike, offering parks, cafes, a Ferris wheel, and great views of the city skyline."
  }
];

const Quiz = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState<number[]>([]);
  const [quizComplete, setQuizComplete] = useState(false);

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option);
  };

  const handleNextQuestion = () => {
    // Check if answer is correct
    const currentQuestion = quizData[currentQuestionIndex];
    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(score + 1);
    }
    
    // Mark question as answered
    if (!answeredQuestions.includes(currentQuestionIndex)) {
      setAnsweredQuestions([...answeredQuestions, currentQuestionIndex]);
    }
    
    setShowResult(false);
    setSelectedOption(null);
    
    // Move to next question or end quiz
    if (currentQuestionIndex < quizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setQuizComplete(true);
    }
  };

  const handleSubmitAnswer = () => {
    if (selectedOption) {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setShowResult(false);
    setScore(0);
    setAnsweredQuestions([]);
    setQuizComplete(false);
  };

  const currentQuestion = quizData[currentQuestionIndex];
  const progress = ((answeredQuestions.length) / quizData.length) * 100;
  const isCorrect = selectedOption === currentQuestion.correctAnswer;

  return (
    <div className="pb-16">
      <Header title="Baku Quiz" subtitle="Test your knowledge about Baku" />
      
      <div className="p-4">
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Progress</span>
            <span className="text-sm font-medium">{answeredQuestions.length} of {quizData.length}</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {!quizComplete ? (
          <Card className="animate-fade-in">
            <CardContent className="p-6">
              <div className="mb-6">
                <h3 className="text-xl font-medium mb-2">Question {currentQuestionIndex + 1}</h3>
                <p className="text-lg">{currentQuestion.question}</p>
              </div>

              <RadioGroup
                value={selectedOption || ""}
                className="space-y-3"
                disabled={showResult}
              >
                {currentQuestion.options.map((option, index) => (
                  <div key={index} className={`flex items-center space-x-2 p-3 border rounded-md ${
                    showResult && option === currentQuestion.correctAnswer 
                      ? 'border-green-500 bg-green-50' 
                      : showResult && option === selectedOption 
                        ? 'border-red-500 bg-red-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <RadioGroupItem 
                      value={option} 
                      id={`option-${index}`} 
                      onClick={() => handleOptionSelect(option)}
                    />
                    <Label 
                      htmlFor={`option-${index}`}
                      className="flex-1 cursor-pointer"
                    >
                      {option}
                    </Label>
                    {showResult && option === currentQuestion.correctAnswer && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                    {showResult && option === selectedOption && option !== currentQuestion.correctAnswer && (
                      <XCircle className="w-5 h-5 text-red-500" />
                    )}
                  </div>
                ))}
              </RadioGroup>

              {showResult && (
                <div className="mt-4 p-4 bg-blue-50 rounded-md">
                  <p className="font-medium text-blue-800">
                    {isCorrect ? "Correct! 🎉" : "Not quite right."}
                  </p>
                  <p className="text-blue-700 mt-1">{currentQuestion.explanation}</p>
                </div>
              )}

              <div className="mt-6 flex justify-end">
                {!showResult ? (
                  <Button 
                    onClick={handleSubmitAnswer}
                    disabled={!selectedOption}
                    className="bg-baku-primary text-white"
                  >
                    Check Answer
                  </Button>
                ) : (
                  <Button 
                    onClick={handleNextQuestion}
                    className="bg-baku-primary text-white"
                  >
                    {currentQuestionIndex < quizData.length - 1 ? "Next Question" : "See Results"}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="animate-fade-in">
            <CardContent className="p-6 text-center">
              <h2 className="text-2xl font-bold mb-4">Quiz Complete!</h2>
              <div className="w-24 h-24 rounded-full bg-baku-primary flex items-center justify-center text-white text-3xl font-bold mx-auto mb-6">
                {score}/{quizData.length}
              </div>
              <p className="text-lg mb-6">
                {score === quizData.length 
                  ? "Perfect score! You're a Baku expert! 🏆"
                  : score >= quizData.length * 0.7 
                    ? "Great job! You know Baku well! 🌟"
                    : "Good effort! Keep exploring Baku to learn more! 🌇"}
              </p>
              <Button 
                onClick={resetQuiz}
                className="bg-baku-primary text-white"
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNav activeTab="home" />
    </div>
  );
};

export default Quiz;