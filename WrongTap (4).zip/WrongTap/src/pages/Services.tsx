import React from 'react';
import { Building, Phone, MapPin, Navigation } from 'lucide-react';
import Header from '@/components/Header';
import BottomNav from '@/components/Navigation/BottomNav';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ServiceCardProps {
  title: string;
  description?: string;
  address?: string;
  phone?: string;
  hours?: string;
  emergency?: boolean;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, address, phone, hours, emergency }) => {
  return (
    <Card className={emergency ? "border-2 border-red-500" : ""}>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center">
          {emergency && <span className="w-2 h-2 rounded-full bg-red-500 mr-2"></span>}
          {title}
        </CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        {address && (
          <div className="flex items-start mb-2">
            <MapPin size={16} className="mr-2 mt-1 text-baku-primary flex-shrink-0" />
            <span className="text-sm">{address}</span>
          </div>
        )}
        {phone && (
          <div className="flex items-center mb-2">
            <Phone size={16} className="mr-2 text-baku-primary flex-shrink-0" />
            <span className="text-sm">{phone}</span>
          </div>
        )}
        {hours && (
          <div className="text-xs text-gray-500 mt-1">
            Working hours: {hours}
          </div>
        )}
        {/* Show Get Directions button only for non-emergency services with addresses */}
        {!emergency && address && (
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-3 w-full bg-gray-50 hover:bg-gray-100"
            onClick={() => {
              if (address) {
                const encodedAddress = encodeURIComponent(`${address}, Baku, Azerbaijan`);
                window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
              }
            }}
          >
            <Navigation size={14} className="mr-1" />
            Get Directions
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

const Services = () => {
  return (
    <div className="pb-16">
      <Header title="Local Services" subtitle="Essential services in Baku" />

      <Tabs defaultValue="emergency" className="w-full">
        <div className="p-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
            <TabsTrigger value="tourist">Tourist Info</TabsTrigger>
            <TabsTrigger value="telecom">Telecom</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="emergency" className="p-4 pt-0 space-y-5">
          <div className="grid grid-cols-1 gap-4 mb-5">
            <div className="bg-gradient-to-r from-red-500 to-red-600 text-white p-4 rounded-xl shadow-lg">
              <h3 className="text-lg font-bold mb-3 flex items-center">
                <span className="bg-white text-red-600 p-1 rounded-full mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                </span>
                Emergency Contact Numbers
              </h3>
              <div className="grid grid-cols-3 gap-3 mt-4">
                <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg text-center flex flex-col justify-between h-full">
                  <div className="text-xs text-white/80 mb-1">General Emergency</div>
                  <div className="text-2xl font-bold mt-1">112</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg text-center flex flex-col justify-between h-full">
                  <div className="text-xs text-white/80 mb-1">Police</div>
                  <div className="text-2xl font-bold mt-1">102</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg text-center flex flex-col justify-between h-full">
                  <div className="text-xs text-white/80 mb-1">Ambulance</div>
                  <div className="text-2xl font-bold mt-1">103</div>
                </div>
              </div>
              <p className="text-sm mt-4 text-white/90">
                All emergency operators may not speak English. If possible, have someone who speaks Azerbaijani help you place the call.
              </p>
            </div>
          </div>
          
          <h3 className="text-lg font-bold mt-4 mb-3 text-gray-800 flex items-center">
            <span className="bg-indigo-100 text-indigo-600 p-1 rounded-md mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            </span>
            Important Facilities
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ServiceCard
              title="Central Hospital"
              address="76 Parliment Ave, Baku"
              phone="+994 12 492 1092"
              hours="Mon-Fri: 9:00 AM - 5:00 PM"
            />

            <ServiceCard
              title="US Embassy"
              address="111 Azadlig Avenue, Baku"
              phone="+994 12 488 3300"
              hours="Mon-Fri: 8:30 AM - 5:30 PM"
            />

            <ServiceCard
              title="British Embassy"
              address="45 Khagani Street, Baku"
              phone="+994 12 437 7878"
              hours="Open 24/7"
            />
          </div>
        </TabsContent>

        <TabsContent value="tourist" className="p-4 pt-0 space-y-5">
          <div className="bg-gradient-to-br from-blue-500 to-teal-500 text-white p-5 rounded-xl shadow-lg">
            <div className="flex items-center mb-4">
              <div className="bg-white/20 p-3 rounded-full mr-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold">Tourist Information</h3>
                <p className="text-white/80 text-sm">Get help with your travel needs</p>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg shadow-inner">
              <div className="flex justify-between items-center mb-2">
                <h4 className="font-medium text-white">Azerbaijan Tourism Board</h4>
                <div className="bg-white/20 px-2 py-1 rounded text-xs">Official</div>
              </div>
              <div className="text-sm text-white/90 mb-3">134 Uzeyir Hajibeyli, Baku 1010</div>
              <div className="flex items-center mt-2">
                <div className="bg-white/20 p-1.5 rounded mr-2">
                  <Phone size={14} className="text-white" />
                </div>
                <span className="text-white text-sm">(012) 505 87 04</span>
              </div>
              <div className="text-xs text-white/70 mt-3">Hours: Mon-Fri 9:00 AM - 6:00 PM</div>
              
              <div className="mt-4 pt-4 border-t border-white/20">
                <div className="grid grid-cols-2 gap-3">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="bg-white/10 border-white/20 text-white hover:bg-white/30"
                    onClick={() => {
                      window.open('https://azerbaijan.travel/en/home', '_blank');
                    }}
                  >
                    <span className="mr-1.5">🌐</span>
                    Visit Website
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="bg-white/10 border-white/20 text-white hover:bg-white/30"
                    onClick={() => {
                      const encodedAddress = encodeURIComponent(`134 Uzeyir Hajibeyli, Baku, Azerbaijan`);
                      window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
                    }}
                  >
                    <Navigation size={14} className="mr-1.5" />
                    Get Directions
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl shadow-sm border border-amber-100">
            <h3 className="text-lg font-bold mb-4 text-amber-800 flex items-center">
              <span className="bg-amber-100 text-amber-600 p-1.5 rounded-full mr-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                </svg>
              </span>
              Common Azerbaijani Phrases
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-amber-600 font-medium uppercase tracking-wider">Greeting</div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-gray-600">Hello</span>
                  <span className="font-bold text-gray-800">Salam</span>
                </div>
              </div>
              
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-amber-600 font-medium uppercase tracking-wider">Gratitude</div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-gray-600">Thank you</span>
                  <span className="font-bold text-gray-800">Təşəkkür edirəm</span>
                </div>
              </div>
              
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-amber-600 font-medium uppercase tracking-wider">Basic Response</div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-gray-600">Yes / No</span>
                  <span className="font-bold text-gray-800">Bəli / Xeyr</span>
                </div>
              </div>
              
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="text-xs text-amber-600 font-medium uppercase tracking-wider">Help</div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-gray-600">Help me please</span>
                  <span className="font-bold text-gray-800">Mənə kömək edin</span>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="telecom" className="p-4 pt-0 space-y-5">
          <div className="bg-gradient-to-r from-violet-500 to-purple-600 text-white p-5 rounded-xl shadow-lg overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mt-10 -mr-10"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -mb-8 -ml-8"></div>
            
            <h3 className="text-xl font-bold mb-3 flex items-center relative z-10">
              <span className="bg-white text-purple-600 p-1.5 rounded-full mr-2 shadow-md">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </span>
              Mobile Operators
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4 relative z-10">
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-xl shadow-inner border border-white/20 hover:bg-white/20 transition duration-300">
                <div className="flex items-center mb-3">
                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                    <span className="text-blue-600 font-bold">A</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-white">Azercell</h4>
                    <div className="text-xs text-white/70">Primary Provider</div>
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-center mb-1">
                    <Phone size={14} className="text-white/60 mr-2" />
                    <span className="text-sm">(012) 490 49 49</span>
                  </div>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-white/60 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-xs text-white/80">24/7 Support</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-xl shadow-inner border border-white/20 hover:bg-white/20 transition duration-300">
                <div className="flex items-center mb-3">
                  <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center mr-3">
                    <span className="text-red-600 font-bold">B</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-white">Bakcell</h4>
                    <div className="text-xs text-white/70">Mobile Network</div>
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-center mb-1">
                    <Phone size={14} className="text-white/60 mr-2" />
                    <span className="text-sm">(+994 12) 444-07-77</span>
                  </div>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-white/60 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-xs text-white/80">24/7 Support</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-xl shadow-inner border border-white/20 hover:bg-white/20 transition duration-300">
                <div className="flex items-center mb-3">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                    <span className="text-green-600 font-bold">N</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-white">Nar</h4>
                    <div className="text-xs text-white/70">Mobile Operator</div>
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex items-center mb-1">
                    <Phone size={14} className="text-white/60 mr-2" />
                    <span className="text-sm">(070) 999 07 77</span>
                  </div>
                  <div className="flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-white/60 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="text-xs text-white/80">24/7 Support</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-50 via-blue-50 to-sky-50 p-6 rounded-xl shadow-sm border border-blue-100">
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              <div className="md:w-1/3 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-lg"></div>
                <div className="relative p-4">
                  <div className="bg-white/80 backdrop-blur-sm shadow-lg rounded-xl p-4 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                    <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-32 rounded-lg flex items-center justify-center text-white font-bold text-2xl shadow-inner">
                      SIM Card
                    </div>
                    <div className="mt-2 text-center font-medium text-gray-800">
                      Tourist Package
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-xl font-bold mb-3 text-gray-800">SIM Card Information</h3>
                <div className="space-y-3">
                  <p className="text-gray-600">
                    Tourists can purchase SIM cards from any of the providers shown above. Remember to bring your passport for registration.
                  </p>
                  
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <h4 className="font-medium text-gray-800 mb-3">Tourist SIM Package Features</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-1.5 rounded-full mr-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span className="text-sm">Internet Data</span>
                      </div>
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-1.5 rounded-full mr-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span className="text-sm">Local Calls</span>
                      </div>
                      <div className="flex items-center">
                        <div className="bg-blue-100 p-1.5 rounded-full mr-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <span className="text-sm">SMS</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <BottomNav activeTab="services" />
    </div>
  );
};

export default Services;