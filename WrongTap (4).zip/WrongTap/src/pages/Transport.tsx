import React, { useState } from 'react';
import Header from '@/components/Header';
import BottomNav from '@/components/Navigation/BottomNav';
import TransportCard from '@/components/Transport/TransportCard';
import { Bus, Search, Info, Clock, Map } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';

interface BusRoute {
  number: string;
  name: string;
  startPoint: string;
  endPoint: string;
  frequency: string;
  stops: string[];
  firstBus: string;
  lastBus: string;
  fare?: string;
  isAeroexpress?: boolean;
  image?: string;
  description?: string;
}

interface MetroRoute {
  number: string;
  name: string;
  startPoint: string;
  endPoint: string;
  frequency: string;
  stations: string[];
  firstTrain: string;
  lastTrain: string;
  fare?: string;
}

type RouteDetails = BusRoute | MetroRoute;

const Transport = () => {
  const [transportType, setTransportType] = useState<'bus' | 'metro'>('bus');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);

  const busRoutes: BusRoute[] = [
    {
      number: "H1",
      name: "Airport Express",
      startPoint: "Airport Terminal 1",
      endPoint: "28 May Station",
      frequency: "20-45 min",
      stops: ["Airport Terminal 1", "Airport Terminal 2", "Surakhani bridge", "Koroglu m/s", "28 May Station"],
      firstBus: "06:00",
      lastBus: "06:00",
      isAeroexpress: true,
      image: "/attached_assets/aero.jpg",
      description: "Buses run every 20 minutes from 06:00 AM till 11:15 PM, and every 45 minutes from 11:15 PM till 06:00 AM next day. Travel time is approximately 30 minutes, subject to weather and traffic conditions."
    },
    { 
      number: "1", 
      name: "28 May - Neftcilar metro", 
      startPoint: "28 May", 
      endPoint: "Neftcilar metro", 
      frequency: "10 min",
      stops: ["28 May", "Neftcilar metro"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "3", 
      name: "Darnagul - Badamdar", 
      startPoint: "Darnagul", 
      endPoint: "Badamdar", 
      frequency: "10 min",
      stops: ["Darnagul", "Badamdar"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "5", 
      name: "Nariman Narimanov - Yasamal", 
      startPoint: "Nariman Narimanov", 
      endPoint: "Yasamal", 
      frequency: "10 min",
      stops: ["Nariman Narimanov", "Yasamal"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "10", 
      name: "Luna Park - Park Yasamal", 
      startPoint: "Luna Park", 
      endPoint: "Park Yasamal", 
      frequency: "10 min",
      stops: ["Luna Park", "Park Yasamal"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "21", 
      name: "28 may metro - Ahmadli metro", 
      startPoint: "28 may metro", 
      endPoint: "Ahmadli metro", 
      frequency: "10 min",
      stops: ["28 may metro", "Ahmadli metro"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "38", 
      name: "Medical University - Koroglu", 
      startPoint: "Medical University", 
      endPoint: "Koroglu", 
      frequency: "10 min",
      stops: ["Medical University", "Koroglu"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "171", 
      name: "Koroglu - Sea Breeze Hotel", 
      startPoint: "Koroglu", 
      endPoint: "Sea Breeze Hotel", 
      frequency: "10 min",
      stops: ["Koroglu", "Sea Breeze Hotel"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "184", 
      name: "Ulduz - Surakhani", 
      startPoint: "Ulduz", 
      endPoint: "Surakhani", 
      frequency: "10 min",
      stops: ["Ulduz", "Surakhani"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "45", 
      name: "Azadliq - 8 mart", 
      startPoint: "Azadliq", 
      endPoint: "8 mart", 
      frequency: "10 min",
      stops: ["Azadliq", "8 mart"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    },
    { 
      number: "Q1", 
      name: "Koroglu - Qala", 
      startPoint: "Koroglu", 
      endPoint: "Qala", 
      frequency: "10 min",
      stops: ["Koroglu", "Qala"],
      firstBus: "07:00",
      lastBus: "21:00",
      fare: "0.50 AZN"
    }
  ];

  const metroRoutes: MetroRoute[] = [
    { 
      number: "1", 
      name: "Red Line", 
      startPoint: "Hazi Aslanov", 
      endPoint: "Icharishahar", 
      frequency: "3 min",
      stations: ["Hazi Aslanov", "Ahmadli", "Xalqlar dostlugu", "Neftchilar", "Qara Qarayev", "Koroglu", "Ulduz", "Bakmil", "Nariman Narimanov", "Ganclik", "Cafar Cabbarli", "Sahil", "Ichari Shahar",],
      firstTrain: "06:00",
      lastTrain: "00:00",
      fare: "0.50 AZN"
    },
    { 
      number: "2", 
      name: "Green Line", 
      startPoint: "Hazi Aslanov", 
      endPoint: "Darnagul", 
      frequency: "5 min",
      stations: ["Hazi Aslanov", "Ahmadli", "Khalglar Dostlugu", "Neftchilar", "Qara Qarayev", "Koroglu", "Ulduz", "Bakmil", "Nariman Narimanov", "Ganjlik", "28 May", "Shah Ismail Khatai", "Nizami", "Elmlar Akademiyasi", "Inshaatchilar", "20 Yanvar", "Memar Acami", "Nasimi", "Azadliq prospekti", "Darnagul",],
      firstTrain: "06:00",
      lastTrain: "00:00",
      fare: "0.50 AZN"
    },
    { 
      number: "3", 
      name: "Purple Line", 
      startPoint: "Khojasan", 
      endPoint: "8 Noyabr", 
      frequency: "6 min",
      stations: ["Khojasan", "Avtovagzal", "Memar Acami", "8 Noyabr",],
      firstTrain: "06:00",
      lastTrain: "00:00",
      fare: "0.50 AZN"
    },
  ];

  const filteredBusRoutes = searchQuery 
    ? busRoutes.filter(route => 
        route.number.toLowerCase().includes(searchQuery.toLowerCase()) || 
        route.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.startPoint.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.endPoint.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : busRoutes;

  const filteredMetroRoutes = searchQuery 
    ? metroRoutes.filter(route => 
        route.number.toLowerCase().includes(searchQuery.toLowerCase()) || 
        route.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.startPoint.toLowerCase().includes(searchQuery.toLowerCase()) ||
        route.endPoint.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : metroRoutes;

  const handleRouteClick = (routeNumber: string) => {
    if (selectedRoute === routeNumber) {
      setSelectedRoute(null);
    } else {
      setSelectedRoute(routeNumber);
    }
  };

  const getSelectedRouteDetails = () => {
    if (!selectedRoute) return null;

    if (transportType === 'bus') {
      return busRoutes.find(route => route.number === selectedRoute);
    } else {
      return metroRoutes.find(route => route.number === selectedRoute);
    }
  };

  const routeDetails = getSelectedRouteDetails();

  const isBusRoute = (route: RouteDetails | null): route is BusRoute => {
    return route !== null && 'stops' in route;
  };

  const isMetroRoute = (route: RouteDetails | null): route is MetroRoute => {
    return route !== null && 'stations' in route;
  };

  return (
    <div className="pb-16 bg-gradient-to-b from-gray-50 to-white">
      <Header title="Public Transport" subtitle="Navigate Baku with ease" />

      <Tabs defaultValue="routes" className="w-full">
        <div className="px-4 pt-2">
          <TabsList className="flex w-full rounded-xl overflow-hidden shadow-sm h-11 p-0 bg-gray-100">
            <TabsTrigger 
              value="routes" 
              className="flex-1 h-full rounded-none py-2 text-sm font-medium data-[state=active]:bg-blue-500 data-[state=active]:text-white"
            >
              Routes
            </TabsTrigger>
            <TabsTrigger 
              value="map" 
              className="flex-1 h-full rounded-none py-2 text-sm font-medium data-[state=active]:bg-blue-500 data-[state=active]:text-white"
            >
              Map
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="routes" className="p-4 pt-3">
          <div className="mb-5 flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">Transport Options</h2>
            <div className="flex space-x-2">
              <Button 
                size="sm" 
                variant={transportType === 'bus' ? "default" : "outline"}
                onClick={() => {
                  setTransportType('bus');
                  setSelectedRoute(null);
                }}
                className={transportType === 'bus' 
                  ? "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 shadow-md"
                  : "hover:bg-blue-50 border-blue-200"}
              >
                <Bus size={16} className="mr-2" />
                Bus
              </Button>
              <Button 
                size="sm" 
                variant={transportType === 'metro' ? "default" : "outline"}
                onClick={() => {
                  setTransportType('metro');
                  setSelectedRoute(null);
                }}
                className={transportType === 'metro' 
                  ? "bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 shadow-md" 
                  : "hover:bg-rose-50 border-rose-200"}
              >
                <Map size={16} className="mr-2" />
                Metro
              </Button>
            </div>
          </div>

          <div className="relative mb-5">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder={`Search ${transportType} routes...`}
              className="pl-10 shadow-sm bg-white border-gray-200 focus:border-blue-300 focus:ring-blue-200"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            {transportType === 'bus' ? (
              filteredBusRoutes.map(route => (
                <div key={route.number}>
                  <div onClick={() => handleRouteClick(route.number)}>
                    <TransportCard 
                      type="bus"
                      number={route.number}
                      name={route.name}
                      startPoint={route.startPoint}
                      endPoint={route.endPoint}
                      frequency={route.frequency}
                      active={selectedRoute === route.number}
                    />
                  </div>
                  {selectedRoute === route.number && (
                    <div className="mt-3 mb-6 bg-gradient-to-br from-white to-sky-50 p-5 rounded-xl border border-gray-200 shadow-lg animate-fade-in">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-md mr-3">
                            {route.number}
                          </div>
                          <div>
                            <h3 className="font-bold text-xl text-gray-800">Bus Details</h3>
                            <div className="flex items-center text-sm text-gray-500">
                              <span className="font-medium">Route #{route.number}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-5 bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500 uppercase font-medium tracking-wide">First Bus</span>
                          <div className="flex items-center mt-2">
                            <Clock size={16} className="text-blue-500 mr-2" />
                            <span className="font-semibold text-gray-800">{route.firstBus}</span>
                          </div>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500 uppercase font-medium tracking-wide">Last Bus</span>
                          <div className="flex items-center mt-2">
                            <Clock size={16} className="text-blue-500 mr-2" />
                            <span className="font-semibold text-gray-800">{route.lastBus}</span>
                          </div>
                        </div>
                        <div className="flex flex-col col-span-2 mt-2 pt-2 border-t">
                          <span className="text-xs text-gray-500 uppercase font-medium tracking-wide">Frequency</span>
                          <div className="flex items-center mt-2">
                            <Info size={16} className="text-blue-500 mr-2" />
                            <span className="font-semibold text-gray-800">Every {route.frequency}</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-5">
                        <h4 className="font-bold text-xl text-gray-800 mb-4 flex items-center">
                          <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-2 rounded-lg mr-3 shadow-sm">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                            </svg>
                          </span>
                          Route Stops
                        </h4>
                        <div className="relative pl-7">
                          <div className="absolute left-2 top-0 bottom-0 w-1.5 bg-gradient-to-b from-green-500 via-blue-400 to-red-500 rounded-full"></div>
                          {route.stops.map((stop, index, array) => (
                            <div key={index} className="relative mb-5 last:mb-0">
                              <div className={`absolute left-[-12px] top-1 w-6 h-6 rounded-full border-2 border-white shadow-md flex items-center justify-center 
                                ${index === 0 
                                  ? 'bg-gradient-to-r from-green-500 to-green-600 text-white' 
                                  : index === array.length - 1 
                                    ? 'bg-gradient-to-r from-red-500 to-red-600 text-white' 
                                    : 'bg-gradient-to-r from-blue-400 to-blue-500 text-white'}`}>
                                {index === 0 ? '↑' : index === array.length - 1 ? '↓' : '•'}
                              </div>
                              <div className="ml-3 bg-white p-4 rounded-xl border border-gray-100 shadow-sm transition-all hover:shadow-md">
                                <div className="font-medium text-gray-800">{stop}</div>
                                {(index === 0 || index === array.length - 1) && (
                                  <div className={`text-xs mt-1 font-medium px-2 py-1 rounded-full inline-block ${
                                    index === 0 
                                      ? 'bg-green-100 text-green-700' 
                                      : 'bg-red-100 text-red-700'
                                  }`}>
                                    {index === 0 ? 'Starting Point' : 'Final Destination'}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))
            ) : (
              filteredMetroRoutes.map(route => (
                <div key={route.number}>
                  <div onClick={() => handleRouteClick(route.number)}>
                    <TransportCard 
                      type="metro"
                      number={route.number}
                      name={route.name}
                      startPoint={route.startPoint}
                      endPoint={route.endPoint}
                      frequency={route.frequency}
                      active={selectedRoute === route.number}
                    />
                  </div>
                  {selectedRoute === route.number && (
                    <div className="mt-3 mb-6 bg-gradient-to-br from-white to-rose-50 p-5 rounded-xl border border-gray-200 shadow-sm animate-fade-in">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <div className="w-12 h-12 rounded-full bg-baku-ruby flex items-center justify-center text-white font-bold text-lg shadow-md mr-3">
                            {route.number}
                          </div>
                          <div>
                            <h3 className="font-bold text-lg text-gray-800">Metro Details</h3>
                            <div className="flex items-center text-sm text-gray-500">
                              <span className="font-medium">Line #{route.number} - {route.name}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-5 bg-white p-3 rounded-lg border border-gray-100">
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500 uppercase font-medium">First Train</span>
                          <div className="flex items-center mt-1">
                            <Clock size={14} className="text-baku-ruby mr-1" />
                            <span className="font-medium">{route.firstTrain}</span>
                          </div>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-xs text-gray-500 uppercase font-medium">Last Train</span>
                          <div className="flex items-center mt-1">
                            <Clock size={14} className="text-baku-ruby mr-1" />
                            <span className="font-medium">{route.lastTrain}</span>
                          </div>
                        </div>
                        <div className="flex flex-col col-span-2">
                          <span className="text-xs text-gray-500 uppercase font-medium">Frequency</span>
                          <div className="flex items-center mt-1">
                            <Info size={14} className="text-baku-ruby mr-1" />
                            <span className="font-medium">Every {route.frequency}</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-5">
                        <h4 className="font-bold text-gray-800 mb-3 flex items-center">
                          <span className="bg-baku-ruby text-white p-1 rounded-md mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                            </svg>
                          </span>
                          Stations
                        </h4>
                        <div className="relative pl-7">
                          <div className="absolute left-2 top-0 bottom-0 w-1 bg-gradient-to-b from-green-500 via-purple-500 to-red-500 rounded-full"></div>
                          {route.stations.map((station, index, array) => (
                            <div key={index} className="relative mb-4 last:mb-0">
                              <div className={`absolute left-[-10px] top-1 w-5 h-5 rounded-full border-2 border-white shadow-md flex items-center justify-center 
                                ${index === 0 
                                  ? 'bg-green-500 text-white' 
                                  : index === array.length - 1 
                                    ? 'bg-red-500 text-white' 
                                    : 'bg-purple-500 text-white'}`}>
                                {index === 0 ? '↑' : index === array.length - 1 ? '↓' : '•'}
                              </div>
                              <div className="ml-3 bg-white p-3 rounded-lg border border-gray-100 shadow-sm">
                                <div className="font-medium text-gray-800">{station}</div>
                                {(index === 0 || index === array.length - 1) && (
                                  <div className={`text-xs mt-1 font-medium ${index === 0 ? 'text-green-600' : 'text-red-600'}`}>
                                    {index === 0 ? 'Starting Point' : 'Final Destination'}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          <div className="mt-6 p-4 bg-baku-light rounded-xl">
            <h3 className="font-medium mb-2">BakuCard Information</h3>
            <p className="text-sm text-gray-700">
              You need to purchase Baku cards from transport terminals and you can use them both for metro or for buses. 
              The card price is 3 manat.
            </p>
            <div className="mt-3 text-sm">
              <div className="flex justify-between py-1 border-b border-gray-200">
                <span>Bus fare:</span>
                <span className="font-medium">Depends on route</span>
              </div>
              <div className="flex justify-between py-1 border-b border-gray-200">
                <span>Metro fare:</span>
                <span className="font-medium">0.50 AZN</span>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="map" className="p-4 pt-0">
          <div className="rounded-xl overflow-hidden h-[500px] shadow-md border border-gray-200">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d194472.42555083955!2d49.715145!3d40.3947365!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40307d6bd6211cf9%3A0x343f6b5e7ae56c6b!2sBaku%2C%20Azerbaijan!5e0!3m2!1sen!2sus!4v1684828736147!5m2!1sen!2sus" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Baku Map"
              className="rounded-xl"
            />
          </div>
          <div className="mt-4 bg-blue-50 p-4 rounded-xl border border-blue-100">
            <h3 className="font-medium text-blue-800 mb-2">Transportation Map</h3>
            <p className="text-sm text-gray-700">
              This map shows the city of Baku. You can use it to navigate and find public transport routes throughout the city.
            </p>
          </div>
        </TabsContent>
      </Tabs>

      <BottomNav activeTab="transport" />
    </div>
  );
};

export default Transport;
